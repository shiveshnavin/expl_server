<?php

include 'header.php';

?>
<title> Expl Oman : Portal </title>
<div id='cssmenu'>
<ul>
  
   <li class='active'><a href='index.php'>Home</a></li>
   <li  ><a href='places.php'>Places</a></li>
   <li><a href='guides.php'>Guides</a></li>
   <li><a href='tours.php'>Tours</a></li>
   <li><a href='users.php'>Users</a></li>
</ul>
</div>
  <section>



<div id="wrapper">
  <div id="three-column" class="container">
    <div class="title">
      <h2>Welcome to Explo Oman Control Panel !</h2><br>
      <span class="byline">You can monitor and Administer the System using this portal </span>
    </div>
    <div class="boxA">
      <p> </p>
      <a href="places.php" class="button button-alt">PLACES</a>
    </div>
    <div class="boxB">
      <p> </p>
      <a href="guides.php" class="button button-alt">GUIDES</a>
    </div>
    <div class="boxC">
      <p> </p>
      <a href="#" class="button button-alt">TOURS</a>
    </div> 

    <div class="boxA"><br><br><br>
      <p> </p>
      <a href="#" class="button button-alt">USERS</a>
    </div>
     <div class="boxB"><br><br><br>
      <p> </p>
      <a href="#" class="button button-alt">TRANSACTIONS</a>
    </div>
     <div class="boxC"><br><br><br>
      <p> </p>
      <a href="#" class="button button-alt">LOGOUT</a>
    </div>
  </div>
</div>




</section>
<?php

include 'footer.php';

?>