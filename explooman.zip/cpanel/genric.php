<?php

include 'header.php';

?>
<div id='cssmenu'>
<ul>
  
   <li class='active'><a href='index.php'>Home</a></li>
   <li ><a href='places.php'>Places</a></li>
   <li><a href='guides.php'>Guides</a></li>
   <li><a href='tours.php'>Tours</a></li>
   <li><a href='users.php'>Users</a></li>
   
</ul>
</div>
  <section>


 

</section>
<?php

include 'footer.php';

?>