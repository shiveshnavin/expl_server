
<!-- follow me template -->
<div class="made-with-love">
  Made By
  <i> </i> by
  <a target="_blank" href="http://thehoproject.co.nf">HopTec Solutions</a>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
